import './style.css';
import React from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import {Typography} from '@mui/material'

const position = [40.3662148, 71.2755422];

const index = () => {
  return (
    <div className="leaflet">
        <Typography color='red'sx={{textAlign:'start'}}><a href="https://www.google.com/maps/dir/Rishtan,+Uzbekistan/40.3737359,71.2636633/@40.3692464,71.2616045,15z/data=!3m1!4b1!4m8!4m7!1m5!1m1!1s0x38bbaa16bf676935:0xffc68ae8a5075c7!2m2!1d71.2755422!2d40.3662148!1m0?hl=en" target='_blank'>View larger map</a></Typography>
      <MapContainer center={position} zoom={12} scrollWheelZoom={true}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <Marker position={position}>
          <Popup>
            A pretty CSS3 popup. <br /> Easily customizable.
          </Popup>
        </Marker>
      </MapContainer>
    </div>
  );
};

export default index;
